#T5

Ejerecicios incluidos:

* EJ4_caballo_ajedrez
* EJ6_Sustitucion

Juan Casado Ballesteros