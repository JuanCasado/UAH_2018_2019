#T1

Ejerecicios incluidos:

* EJ3_Complejidad_del_código (en el pdf)
* EJ6_Numeros_perfectos
* EJ9_Sumatorio_recursivo

Juan Casado Ballesteros